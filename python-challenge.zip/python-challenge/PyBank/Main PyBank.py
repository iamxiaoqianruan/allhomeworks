#buget_data.csv and python file are in the same folder
import os
import csv

csvpath = os.path.join('budget_data.csv')

with open(csvpath, 'r', newline='') as csvfile:

    # CSV reader specifies delimiter and variable that holds contents
    csvreader = csv.reader(csvfile)
    next(csvreader)


    sum = 0
    profitlist = []
    monthlist = []
    for row in csvreader:
        profitlist.append(int(row[1]))
        monthlist.append(row[0])
        sum += int((row[1]))

    total_months = len(profitlist)
    total_profitloss = sum
    average = round(total_profitloss/total_months)
    max = max(profitlist)
    min = min(profitlist)
    max_index = profitlist.index(max)
    min_index = profitlist.index(min)
    max_month = monthlist[max_index]
    min_month = monthlist[min_index]
    # print(total_months)
    # print(average)
    # print(total_profitloss)
    # print(max)
    # print(min)
    # print(min_month)
    # print(max_month)
    print('Financial Analysis\n' + f'Total Months: {total_months}\n' + f'Total: ${total_profitloss}\n' + f'Average Change: ${average}\n'
          + f'Greatest Increase in Profits: {max_month} (${max})\n'
          + f'Greatest Decrease in Profits: {min_month} (${min})\n')