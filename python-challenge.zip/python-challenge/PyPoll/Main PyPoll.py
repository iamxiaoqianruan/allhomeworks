import os
import csv

csvpath = os.path.join('test_data.csv')
perm_file = []
with open(csvpath, 'r', newline='') as csvfile:

    # CSV reader specifies delimiter and variable that holds contents
    csvreader = csv.reader(csvfile)
    next(csvreader)
    #define total votes
    sum = 0
    # Read each row of data after the header
    for row in csvreader:
        perm_file.append(row)
        sum = sum + int(row[0])

 #store candidates in a list
candidates = []
for row in perm_file:
    if row[2] in candidates:
        pass
    else:
        candidates.append(row[2])
#aggregate votes for each candidate
votes=[]
percentage = []

for name in candidates:
    vote=0
    percent = 0
    for row in perm_file:
        if row[2] == name:
            vote = vote + int(row[0])
    percent = vote/sum
    votes.append(vote)
    percentage.append(percent)

#print(votes)
#print(percentage)

#create dict to store candidate, votes and percentage lists.
summary_dict = {
    "Candidates":candidates,
    "Percentage":percentage,
    "Votes": votes
}
#print(summary_dict)

#zip candidate, votes and percentage lists.
summary_db = zip(candidates,percentage,votes)

#find the winner
winner = candidates[percentage.index(max(percentage))]

print(f'Election Results\n'+
     '---------------------\n'+
     f'Total Votes: {sum}\n'+
     '---------------------\n'
     )
for each in summary_db:
    print(f'{each[0]}: '+'{:.0%}'.format(each[1])+f'({each[2]})')
print(f'---------------------\n'+
     f'Winner: {winner}\n'
     )


